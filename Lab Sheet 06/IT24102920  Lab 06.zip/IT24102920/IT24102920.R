setwd("C:\\Users\\hashe\\OneDrive\\Desktop\\IT24102920")
getwd()
pbinom(46,50,0.85,lower.tail = FALSE)
dpois(15,12)
